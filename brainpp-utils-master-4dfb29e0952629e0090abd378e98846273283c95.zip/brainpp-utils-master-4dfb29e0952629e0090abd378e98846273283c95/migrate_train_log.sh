#!/bin/bash -e
set -x

[ $# != 1 ] && echo "Usage: $0 <train_log_dir>" && exit 1
tld="$1"

[ ! -d "$tld" ] && echo "$tld is not a directory"  && exit 1
[ "$(basename "$tld")" != train_log ] && echo "directory should be named train_log" && exit 1

u=$(whoami)

shared_root=/unsullied/sharefs/$u/ceph-home
train_log_root=$shared_root/.cache/neupeak/train_log
[ ! -d $shared_root ] && selfctl mount $u/ceph-home

dst="$train_log_root/$(readlink -f "$tld")"
[ -e "$dst" ] && echo "$dst exists" && exit 1
dst_dir="$(dirname "$dst")"
mkdir -p "$dst_dir"
mv "$tld" "$dst_dir" -v
ln -sv "$dst" "$tld"

