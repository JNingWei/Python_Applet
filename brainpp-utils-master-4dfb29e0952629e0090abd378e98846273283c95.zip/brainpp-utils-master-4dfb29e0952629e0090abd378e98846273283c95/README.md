## setup bash

```sh
cp bootstrap-script/profile ~/.profile
cp bootstrap-script/bash_brainpp ~/.bash_brainpp
echo '[[ -z $HAS_BRAINPP_UTILS ]] && . ~/.bash_brainpp' >> ~/.bashrc
```
