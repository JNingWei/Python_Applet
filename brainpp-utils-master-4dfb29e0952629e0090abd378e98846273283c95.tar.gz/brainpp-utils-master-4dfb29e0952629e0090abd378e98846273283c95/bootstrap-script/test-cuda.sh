#!/bin/bash

cd $HOME/local/megdl-examples/mnist
mgh-train trainer_desc.py
