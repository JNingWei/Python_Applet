#!/bin/bash
set -x

if [[ ! -z "$RLAUNCH_WORKER" ]]; then
    echo "You are in an rlaunch worker! GO BACK to the master workspace!"
    exit 1
fi

cd "$(dirname "$(readlink -f "$0")")"

export all_proxy=http://proxy.i.brainpp.cn:3128 no_proxy=.i.brainpp.ml,.sm.megvii-op.org,.brainpp.cn,127.0.0.1,localhost; export http_proxy=$all_proxy https_proxy=$all_proxy

sudo apt update && sudo apt install -y jq

if [[ ! -d "/unsullied/sharefs/$USER/isilon-home" ]]; then
    echo "You MUST create a shared storage with name 'isilon-home' and type 'ISILON'."
    exit 1
fi

# for workspace
sudo chmod +w /unsullied/sharefs/$USER/{@nfshome,isilon-home}

sudo mkdir -p /data

u=$USER


# set locale
export LANG=en_US.UTF-8
sudo apt install -y locales && \
    sudo sed -i -e "s/# $LANG UTF-8/$LANG UTF-8/" /etc/locale.gen && \
    sudo dpkg-reconfigure --frontend=noninteractive locales && \
    sudo update-locale LANG=$LANG
export LC_ALL=en_US.UTF-8

# install megdl
msm update

# libboost-all-dev for scribe
# python3-httplib2 for megnori
# parallel for job automation
# openjdk-8-jre for bazel

sudo apt install -y \
    libopencv-dev python3-tk libgeos-dev \
    python3-sklearn python3-networkx python3-seaborn \
    python3-httplib2 \
    libboost-all-dev \
    libopenblas-dev \
    g++-4.8 \
    parallel \
    openjdk-8-jre \
    gnuplot \
    python-watchdog \
    inotify-tools \
    redis-server

if [[ ! -d $HOME/neupeak/neupeak ]]; then
    (cd $HOME; git clone git@git-core.megvii-inc.com:ImageTeam/neupeak.git)
    export PYTHONPATH=$HOME/neupeak:$PYTHONPATH
    $HOME/neupeak/bin/npk-update dev
    $HOME/neupeak/bin/npk-update dev
    $HOME/neupeak/bin/npk-update dev
fi

sudo -E pip_brain install nori2 dpflow rrun tensorflow

# vim: ts=4 sts=4 sw=4 expandtab
