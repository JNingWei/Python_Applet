#!/bin/bash -e
set -x

cd "$(dirname "$(readlink -f "$0")")"

export all_proxy=http://proxy.i.brainpp.cn:3128 no_proxy=.i.brainpp.ml,.sm.megvii-op.org,.brainpp.cn,127.0.0.1,localhost; export http_proxy=$all_proxy https_proxy=$all_proxy

bash bootstrap.minimal.sh || { 
    echo "Bootstrap Failed"
    exit 1 
}

if [[ -d /unsullied/sharefs/wangyuzhi/shared-utils/ ]]; then
    sudo apt-key add /unsullied/sharefs/wangyuzhi/shared-utils/ppa/tmux/gpg.key
    echo "deb file:///unsullied/sharefs/wangyuzhi/shared-utils/ppa/tmux xenial main " | sudo tee /etc/apt/sources.list.d/tmux.list
    sudo apt update
fi

sudo apt install -y \
    zsh \
    silversearcher-ag \
    dstat htop cython3 \
    geeqie \
    tig \
    autojump \
    tree \
    thunar \
    exuberant-ctags \
    tmux

sudo -E pip_brain install flake8

# vim: ts=4 sts=4 sw=4 expandtab
